@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0download-model.ps1"
pause
